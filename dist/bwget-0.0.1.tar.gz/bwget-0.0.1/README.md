# better-wget
Script written to make wget more efficient, which restarts `wget` when download speed is below a certain limit.

## how to use
-
- bwget \[url\] \[destination\] \[speed in kBps]


## todo
- make it generic and give control to user through CLI
- log download percentage and/or other stuff
- check and control download failures, very low speeds, etc.
- show user log if he/she wants to
- handle 'finished' status of downloads
